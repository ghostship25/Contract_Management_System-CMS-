import React, { useState } from 'react';
import { Contract } from '../types';
import { FileText, Printer, ChevronLeft, Send, CheckCircle2 } from 'lucide-react';

interface LetterCenterProps {
  contracts: Contract[];
  onBack: () => void;
}

type LetterType = 'CALL_LETTER' | 'WORK_ORDER' | 'PAYMENT_LETTER' | 'EXTENSION_LETTER' | 'COMPLETION_LETTER';

export const LetterCenter: React.FC<LetterCenterProps> = ({ contracts, onBack }) => {
  const [selectedContractId, setSelectedContractId] = useState<string>('');
  const [selectedLetter, setSelectedLetter] = useState<LetterType>('WORK_ORDER');
  const [customText, setCustomText] = useState<string>('');

  const selectedContract = contracts.find(c => c.id === selectedContractId);

  const letterTemplates: Record<LetterType, { title: string; content: (c: Contract) => string }> = {
    CALL_LETTER: {
      title: 'सम्पर्क गर्ने पत्र (Call Letter)',
      content: (c) => `विषय: सम्झौताका लागि सम्पर्क गर्ने बारे ।

श्री ${c.firmName},
${c.firmAddress} ।

प्रस्तुत विषयमा यस कार्यालयबाट मिति ${c.noticeDate} मा प्रकाशित सूचना अनुसार बोलपत्र आह्वान गरिएकोमा तपाइँको फर्मको बोलपत्र स्वीकृत हुने देखिएकोले यो पत्र प्राप्त भएको मितिले ७ (सात) दिन भित्र आवश्यक धरौटी रकम र कागजात सहित सम्झौताका लागि यस कार्यालयमा उपस्थित हुन जानकारी गराइन्छ ।`
    },
    WORK_ORDER: {
      title: 'कार्यादेश (Work Order)',
      content: (c) => `विषय: कार्यादेश दिइएको बारे ।

महोदय,
उपरोक्त सम्बन्धमा यस कार्यालयको सूचना नं. ${c.tenderNo} अनुसार ${c.projectName} कार्यको लागि तपाइँको फर्म ${c.firmName} को बोलपत्र स्वीकृत भएकोले यो कार्यादेश प्रदान गरिएको छ ।

सम्झौता रकम: Rs. ${Number(c.contractAmount).toLocaleString()}
सम्झौता मिति: ${c.contractDate}
सम्पन्न हुनुपर्ने मिति: ${c.completionDate}

तोकिएको शर्त बमोजिम समयमै कार्य सम्पन्न गर्नुहुनेछ भन्ने विश्वास लिइएको छ ।`
    },
    PAYMENT_LETTER: {
      title: 'भुक्तानी अनुरोध (Payment Request)',
      content: (c) => `विषय: भुक्तानी सम्बन्धमा ।

श्री आर्थिक प्रशासन शाखा,
यस कार्यालयबाट सञ्चालित ${c.projectName} योजनाको कार्य ${c.physicalProgress}% सम्पन्न भएकोले प्राविधिक प्रतिवेदनको आधारमा निर्माण व्यवसायी ${c.firmName} लाई तपसिल बमोजिमको रकम भुक्तानीको लागि अनुरोध छ ।

भुक्तानी किस्ता: ${c.installments.length + 1} औं
अनुरोध रकम: Rs. ${(Number(c.contractAmount) * 0.2).toLocaleString()} (अन्दाजी २०%)
कैफियत: कार्य मूल्याङ्कनको आधारमा`
    },
    EXTENSION_LETTER: {
      title: 'म्याद थप (Time Extension)',
      content: (c) => `विषय: म्याद थप सम्बन्धमा ।

महोदय,
यस कार्यालय र तपाइँको फर्म बीच मिति ${c.contractDate} मा सम्झौता भएको ${c.projectName} को म्याद ${c.completionDate} सम्म रहेकोमा, तपाइँको निवेदन र प्राविधिक राय अनुसार मिति ${c.extensionDate || '..........'} सम्मका लागि म्याद थप गरिएको जानकारी गराइन्छ ।`
    },
    COMPLETION_LETTER: {
      title: 'सम्पन्न प्रतिवेदन (Completion Certificate)',
      content: (c) => `विषय: कार्य सम्पन्न भएको प्रमाणपत्र ।

प्रमाणित गरिन्छ कि ${c.projectName} को कार्य ${c.firmName} ले सम्झौता बमोजिम सफलतापूर्वक सम्पन्न गरेको छ ।

कुल सम्झौता रकम: Rs. ${Number(c.contractAmount).toLocaleString()}
वास्तविक सम्पन्न मिति: ${new Date().toLocaleDateString('ne-NP')}
गुणस्तर: सन्तोषजनक`
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="animate-fadeIn">
      <div className="flex items-center justify-between mb-8 no-print">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-bold transition-colors">
          <ChevronLeft size={20} /> पछाडि जानुहोस्
        </button>
        <h2 className="text-2xl font-black text-gray-800">पत्र निर्माण केन्द्र (Letter Center)</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 no-print">
        {/* Selection Column */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">योजना छान्नुहोस्</label>
            <select 
              className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
              value={selectedContractId}
              onChange={(e) => {
                const id = e.target.value;
                setSelectedContractId(id);
                const contract = contracts.find(c => c.id === id);
                if (contract) setCustomText(letterTemplates[selectedLetter].content(contract));
              }}
            >
              <option value="">-- योजना छान्नुहोस् --</option>
              {contracts.map(c => (
                <option key={c.id} value={c.id}>{c.projectName}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">पत्रको प्रकार</label>
            <div className="grid grid-cols-1 gap-2">
              {(Object.keys(letterTemplates) as LetterType[]).map(type => (
                <button
                  key={type}
                  onClick={() => {
                    setSelectedLetter(type);
                    if (selectedContract) setCustomText(letterTemplates[type].content(selectedContract));
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-3 transition-all ${selectedLetter === type ? 'bg-blue-600 text-white shadow-lg' : 'bg-gray-50 text-gray-600 hover:bg-gray-100'}`}
                >
                  <FileText size={18} />
                  <span className="text-sm font-bold">{letterTemplates[type].title}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Editor Column */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col">
          <label className="block text-sm font-bold text-gray-700 mb-2">पत्रको व्यहोरा (सम्पादन गर्न सकिने)</label>
          <textarea 
            className="flex-grow w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none min-h-[400px] text-gray-700 leading-relaxed"
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder="योजना छान्नुहोस् र पत्र तयार गर्नुहोस्..."
          ></textarea>
          <div className="mt-6 flex justify-end gap-4">
            <button 
              onClick={handlePrint}
              disabled={!selectedContractId}
              className="px-8 py-3 bg-blue-700 text-white rounded-xl font-black flex items-center gap-2 hover:bg-blue-800 transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              <Printer size={20} /> प्रिन्ट गर्नुहोस्
            </button>
          </div>
        </div>
      </div>

      {/* Print Preview Layout */}
      <div className="print-only hidden p-12 bg-white text-black min-h-screen font-serif">
        <div className="max-w-3xl mx-auto border-t-8 border-blue-900 pt-10 px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-2">ठेक्का व्यवस्थापन प्रणाली (CMS)</h1>
            <div className="w-24 h-1 bg-gray-200 mx-auto"></div>
          </div>
          
          <div className="flex justify-between mb-12 font-bold">
            <p>प.सं.: ..........</p>
            <p>च.नं.: ..........</p>
            <p>मिति: {new Date().toLocaleDateString('ne-NP')}</p>
          </div>

          <div className="text-center mb-10">
            <h2 className="text-xl font-black underline">{letterTemplates[selectedLetter].title}</h2>
          </div>

          <div className="whitespace-pre-wrap leading-loose mb-20 text-lg">
            {customText}
          </div>

          <div className="flex justify-end mt-20">
            <div className="text-center w-64 border-t border-black pt-4">
              <p className="font-bold">प्रशासकीय प्रमुख / कार्यालय प्रमुख</p>
              <p className="text-xs mt-1">(छाप र हस्ताक्षर)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};