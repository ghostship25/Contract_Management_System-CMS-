
import React from 'react';
import { Contract, PBData, APGData, InsuranceData, InstallmentData } from '../types';
import { Input, Select } from './Input';
import { ChevronDown, ChevronUp, Save, X, Plus, Trash2 } from 'lucide-react';

interface ContractFormProps {
  initialData: Contract;
  onSave: (data: Contract) => void;
  onCancel: () => void;
}

export const ContractForm: React.FC<ContractFormProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = React.useState<Contract>(initialData);
  const [activeSection, setActiveSection] = React.useState<string>('basic');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const addArrayItem = (key: keyof Contract, template: any) => {
    setFormData(prev => ({
      ...prev,
      [key]: [...(prev[key] as any[]), { ...template, id: Date.now().toString() }]
    }));
  };

  const removeArrayItem = (key: keyof Contract, id: string) => {
    setFormData(prev => ({
      ...prev,
      [key]: (prev[key] as any[]).filter(item => item.id !== id)
    }));
  };

  const updateArrayItem = (key: keyof Contract, id: string, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [key]: (prev[key] as any[]).map(item => item.id === id ? { ...item, [field]: value } : item)
    }));
  };

  const SectionHeader = ({ id, title }: { id: string; title: string }) => (
    <button
      type="button"
      onClick={() => setActiveSection(activeSection === id ? '' : id)}
      className="w-full flex items-center justify-between p-4 bg-gray-50 border-b hover:bg-gray-100 transition-colors"
    >
      <span className="font-bold text-gray-800 flex items-center gap-2">
        <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-xs">{id.toUpperCase()}</span>
        {title}
      </span>
      {activeSection === id ? <ChevronUp size={20} className="text-gray-400" /> : <ChevronDown size={20} className="text-gray-400" />}
    </button>
  );

  return (
    <div className="bg-white rounded-xl shadow-xl border border-gray-200 overflow-hidden mb-10">
      <div className="p-6 bg-gradient-to-r from-blue-800 to-blue-900 text-white flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">ठेक्का व्यवस्थापन फारम</h2>
          <p className="text-blue-100 text-sm mt-1">योजनाको विस्तृत विवरण सुरक्षित गर्नुहोस्</p>
        </div>
        <button onClick={onCancel} className="hover:bg-white/10 p-2 rounded-full transition-colors">
          <X size={24} />
        </button>
      </div>

      <form className="p-0" onSubmit={(e) => { e.preventDefault(); onSave(formData); }}>
        {/* Section 1: Basic Information */}
        <SectionHeader id="basic" title="१. आधारभूत विवरण (Basic Details)" />
        {activeSection === 'basic' && (
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
            <Input label="आर्थिक वर्ष" name="fiscalYear" value={formData.fiscalYear} onChange={handleChange} />
            <Input label="बोलपत्र/दरभाउ पत्र नं." name="tenderNo" value={formData.tenderNo} onChange={handleChange} />
            <Input label="सूचना प्रकाशन मिति" type="date" name="noticeDate" value={formData.noticeDate} onChange={handleChange} />
            <Input label="योजनाको नाम" name="projectName" className="md:col-span-2" value={formData.projectName} onChange={handleChange} />
            <Input label="कुल ल.ई. (Estimated Rs.)" type="number" name="totalEstCost" value={formData.totalEstCost} onChange={handleChange} />
            <Input label="अनुदान शिर्षक" name="grantTitle" value={formData.grantTitle} onChange={handleChange} />
            <Input label="न.पा. अनुदान" type="number" name="municipalityGrant" value={formData.municipalityGrant} onChange={handleChange} />
            <Input label="वडा नं." type="number" name="wardNo" value={formData.wardNo} onChange={handleChange} />
            <Input label="योजनाको किसिम" name="projectType" value={formData.projectType} placeholder="उदा: सडक, भवन" onChange={handleChange} />
            <Select 
              label="योजना संचालन विधि" 
              name="projectMode" 
              value={formData.projectMode} 
              onChange={handleChange}
              options={[
                { value: 'contract', label: 'ठेक्का सम्झौता' },
                { value: 'user_committee', label: 'उपभोक्ता समिति' },
                { value: 'departmental', label: 'अमानत' }
              ]}
            />
          </div>
        )}

        {/* Section 2: Budget & Contracts */}
        <SectionHeader id="budget" title="२. बजेट र सम्झौता (Budget & Contract)" />
        {activeSection === 'budget' && (
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
            <Input label="विनियोजित बजेट" type="number" name="budgetThisFY" value={formData.budgetThisFY} onChange={handleChange} />
            <div className="flex items-center gap-2 pt-8">
              <input 
                type="checkbox" 
                className="w-5 h-5 rounded text-blue-600"
                id="sourceAssuranceRequired" 
                name="sourceAssuranceRequired" 
                checked={formData.sourceAssuranceRequired} 
                onChange={(e) => handleChange(e as any)} 
              />
              <label htmlFor="sourceAssuranceRequired" className="text-sm font-medium">श्रोत सुनिश्चित गर्नु पर्ने?</label>
            </div>
            <Input label="सुनिश्चित गरेको श्रोत" name="assuredSource" value={formData.assuredSource} onChange={handleChange} />
            <Input label="सम्झौता रकम (Contract Amount)" type="number" name="contractAmount" value={formData.contractAmount} onChange={handleChange} />
            <Input label="सम्झौता मिति" type="date" name="contractDate" value={formData.contractDate} onChange={handleChange} />
            <Input label="सम्पन्न हुने मिति" type="date" name="completionDate" value={formData.completionDate} onChange={handleChange} />
            <Input label="म्याद थप मिति" type="date" name="extensionDate" value={formData.extensionDate} onChange={handleChange} />
            <Input label="थप अवधि (महिना/दिन)" name="extendedPeriod" value={formData.extendedPeriod} onChange={handleChange} />
            <Input label="भौतिक प्रगति (%)" type="number" name="physicalProgress" value={formData.physicalProgress} onChange={handleChange} />
          </div>
        )}

        {/* Section 3: Contractor Info */}
        <SectionHeader id="contractor" title="३. निर्माण व्यवसायी/फर्म (Contractor Info)" />
        {activeSection === 'contractor' && (
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
            <Input label="व्यवसायी/फर्मको नाम" name="firmName" value={formData.firmName} onChange={handleChange} />
            <Input label="फर्मको ठेगाना" name="firmAddress" value={formData.firmAddress} onChange={handleChange} />
            <Input label="प्यान नं. (PAN)" name="panNo" value={formData.panNo} onChange={handleChange} />
            <Input label="प्रोप्राइटरको नाम" name="proprietorName" value={formData.proprietorName} onChange={handleChange} />
            <Input label="प्रोप्राइटर सम्पर्क नं." name="proprietorContact" value={formData.proprietorContact} onChange={handleChange} />
            <Input label="साइट ईन्चार्ज" name="siteInCharge" value={formData.siteInCharge} onChange={handleChange} />
            <Input label="साइट सम्पर्क नं." name="contactNo" value={formData.contactNo} onChange={handleChange} />
          </div>
        )}

        {/* Section 4: Dynamic Guarantees & Insurance */}
        <SectionHeader id="guarantee" title="४. जमानत र बीमा (Guarantees & Insurance)" />
        {activeSection === 'guarantee' && (
          <div className="p-6 space-y-8 animate-fadeIn">
            {/* Performance Bonds */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-blue-800">कार्य सम्पादन जमानत (Performance Bonds)</h4>
                <button 
                  type="button"
                  onClick={() => addArrayItem('pbRecords', { institution: '', no: '', amount: '', expiry: '', remarks: '' })}
                  className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded flex items-center gap-1 hover:bg-blue-700 transition-colors"
                >
                  <Plus size={14} /> थप्नुहोस्
                </button>
              </div>
              {formData.pbRecords.map((pb) => (
                <div key={pb.id} className="grid grid-cols-1 md:grid-cols-5 gap-3 p-4 border rounded-lg mb-3 relative bg-gray-50">
                  <Input label="जारी गर्ने संस्था" value={pb.institution} onChange={(e) => updateArrayItem('pbRecords', pb.id, 'institution', e.target.value)} />
                  <Input label="जमानत नं." value={pb.no} onChange={(e) => updateArrayItem('pbRecords', pb.id, 'no', e.target.value)} />
                  <Input label="रकम" type="number" value={pb.amount} onChange={(e) => updateArrayItem('pbRecords', pb.id, 'amount', e.target.value)} />
                  <Input label="म्याद" type="date" value={pb.expiry} onChange={(e) => updateArrayItem('pbRecords', pb.id, 'expiry', e.target.value)} />
                  <div className="flex items-end gap-2">
                    <Input label="कैफियत" className="flex-grow" value={pb.remarks} onChange={(e) => updateArrayItem('pbRecords', pb.id, 'remarks', e.target.value)} />
                    <button type="button" onClick={() => removeArrayItem('pbRecords', pb.id)} className="p-2 text-red-600 hover:bg-red-50 rounded mb-0.5"><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>

            {/* APG */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-blue-800">पेशकी जमानत (Advance Payment Guarantees)</h4>
                <button 
                  type="button"
                  onClick={() => addArrayItem('apgRecords', { institution: '', no: '', amount: '', expiry: '', remarks: '' })}
                  className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded flex items-center gap-1 hover:bg-blue-700"
                >
                  <Plus size={14} /> थप्नुहोस्
                </button>
              </div>
              {formData.apgRecords.map((apg) => (
                <div key={apg.id} className="grid grid-cols-1 md:grid-cols-5 gap-3 p-4 border rounded-lg mb-3 bg-gray-50">
                  <Input label="जारी गर्ने संस्था" value={apg.institution} onChange={(e) => updateArrayItem('apgRecords', apg.id, 'institution', e.target.value)} />
                  <Input label="जमानत नं." value={apg.no} onChange={(e) => updateArrayItem('apgRecords', apg.id, 'no', e.target.value)} />
                  <Input label="रकम" type="number" value={apg.amount} onChange={(e) => updateArrayItem('apgRecords', apg.id, 'amount', e.target.value)} />
                  <Input label="म्याद" type="date" value={apg.expiry} onChange={(e) => updateArrayItem('apgRecords', apg.id, 'expiry', e.target.value)} />
                  <div className="flex items-end gap-2">
                    <Input label="कैफियत" className="flex-grow" value={apg.remarks} onChange={(e) => updateArrayItem('apgRecords', apg.id, 'remarks', e.target.value)} />
                    <button type="button" onClick={() => removeArrayItem('apgRecords', apg.id)} className="p-2 text-red-600 hover:bg-red-50 rounded mb-0.5"><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>

            {/* Insurances */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-blue-800">बीमा विवरण (Insurances)</h4>
                <button 
                  type="button"
                  onClick={() => addArrayItem('insuranceRecords', { institution: '', no: '', expiry: '', remarks: '' })}
                  className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded flex items-center gap-1 hover:bg-blue-700"
                >
                  <Plus size={14} /> थप्नुहोस्
                </button>
              </div>
              {formData.insuranceRecords.map((ins) => (
                <div key={ins.id} className="grid grid-cols-1 md:grid-cols-4 gap-3 p-4 border rounded-lg mb-3 bg-gray-50">
                  <Input label="बीमा कम्पनी" value={ins.institution} onChange={(e) => updateArrayItem('insuranceRecords', ins.id, 'institution', e.target.value)} />
                  <Input label="बीमा नं." value={ins.no} onChange={(e) => updateArrayItem('insuranceRecords', ins.id, 'no', e.target.value)} />
                  <Input label="म्याद" type="date" value={ins.expiry} onChange={(e) => updateArrayItem('insuranceRecords', ins.id, 'expiry', e.target.value)} />
                  <div className="flex items-end gap-2">
                    <Input label="कैफियत" className="flex-grow" value={ins.remarks} onChange={(e) => updateArrayItem('insuranceRecords', ins.id, 'remarks', e.target.value)} />
                    <button type="button" onClick={() => removeArrayItem('insuranceRecords', ins.id)} className="p-2 text-red-600 hover:bg-red-50 rounded mb-0.5"><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section 5: Dynamic Installments */}
        <SectionHeader id="installments" title="५. भुक्तानी र किस्ता (Payments & Installments)" />
        {activeSection === 'installments' && (
          <div className="p-6 space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-500 italic">योजनाको मूल्यांकनको आधारमा भुक्तानी किस्ताहरू थप्नुहोस्।</p>
              <button 
                type="button"
                onClick={() => addArrayItem('installments', { amount: '', payoutDate: '', evaluationAmount: '', remarks: '' })}
                className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700 transition-shadow shadow-md font-bold"
              >
                <Plus size={18} /> नयाँ किस्ता थप्नुहोस्
              </button>
            </div>
            
            <div className="space-y-4">
              {formData.installments.map((inst, index) => (
                <div key={inst.id} className="relative p-6 border-l-4 border-l-blue-600 border border-gray-200 rounded-r-xl bg-white shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute -left-3 top-4 bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold border-2 border-white shadow">
                    {index + 1}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <Input label="भुक्तानी रकम (Rs.)" type="number" value={inst.amount} onChange={(e) => updateArrayItem('installments', inst.id, 'amount', e.target.value)} />
                    <Input label="निकासा मिति" type="date" value={inst.payoutDate} onChange={(e) => updateArrayItem('installments', inst.id, 'payoutDate', e.target.value)} />
                    <Input label="मूल्याङ्कन रकम" type="number" value={inst.evaluationAmount} onChange={(e) => updateArrayItem('installments', inst.id, 'evaluationAmount', e.target.value)} />
                    <div className="flex items-end gap-2">
                      <Input label="कैफियत" className="flex-grow" value={inst.remarks} onChange={(e) => updateArrayItem('installments', inst.id, 'remarks', e.target.value)} />
                      <button type="button" onClick={() => removeArrayItem('installments', inst.id)} className="p-2 text-red-600 hover:bg-red-50 rounded border border-transparent hover:border-red-200 transition-colors">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {formData.installments.length === 0 && (
                <div className="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl text-gray-400">
                  अहिलेसम्म कुनै पनि भुक्तानी किस्ता थपिएको छैन।
                </div>
              )}
            </div>
          </div>
        )}

        <div className="p-8 bg-gray-50 border-t flex flex-col md:flex-row justify-between items-center gap-4 sticky bottom-0 z-20 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
          <p className="text-xs text-gray-500">Note: यस प्रणालीमा प्रविष्ट गरिएका सबै विवरणहरू गोप्य र स्थानीय रूपमा मात्र सुरक्षित हुन्छन्।</p>
          <div className="flex gap-4 w-full md:w-auto">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 md:flex-none px-8 py-3 border border-gray-300 rounded-xl text-gray-700 font-bold hover:bg-white transition-all active:scale-95"
            >
              खारेज (Cancel)
            </button>
            <button
              type="submit"
              className="flex-1 md:flex-none px-12 py-3 bg-blue-700 text-white rounded-xl hover:bg-blue-800 transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 font-bold"
            >
              <Save size={20} />
              सुरक्षित गर्नुहोस् (Save)
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
