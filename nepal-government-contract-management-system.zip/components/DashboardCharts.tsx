import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import { Contract } from '../types';

interface DashboardChartsProps {
  contracts: Contract[];
}

export const DashboardCharts: React.FC<DashboardChartsProps> = ({ contracts }) => {
  // Data for Project Status Pie Chart
  const statusData = React.useMemo(() => {
    if (!contracts.length) return [];
    
    const counts: Record<string, number> = {
      'चालु': 0,
      'सम्पन्न': 0,
      'म्याद नाघेको': 0
    };
    
    contracts.forEach(c => {
      const progress = Number(c.physicalProgress) || 0;
      if (progress === 100) counts['सम्पन्न']++;
      else counts['चालु']++;
    });

    return Object.entries(counts)
      .filter(([_, value]) => value > 0)
      .map(([name, value]) => ({ name, value }));
  }, [contracts]);

  // Data for Ward Distribution Bar Chart
  const wardData = React.useMemo(() => {
    if (!contracts.length) return [];
    
    const wards: Record<string, number> = {};
    contracts.forEach(c => {
      const ward = c.wardNo || 'N/A';
      wards[ward] = (wards[ward] || 0) + (Number(c.contractAmount) || 0);
    });

    return Object.entries(wards)
      .map(([ward, amount]) => ({ ward: `वडा ${ward}`, amount }))
      .sort((a, b) => {
        const aNum = parseInt(a.ward.replace(/\D/g, '')) || 0;
        const bNum = parseInt(b.ward.replace(/\D/g, '')) || 0;
        return aNum - bNum;
      });
  }, [contracts]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  if (!contracts.length) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
        <div className="bg-white p-12 rounded-2xl border border-dashed border-gray-200 text-center text-gray-400">
          चार्ट देखाउन पर्याप्त डाटा छैन।
        </div>
        <div className="bg-white p-12 rounded-2xl border border-dashed border-gray-200 text-center text-gray-400">
          चार्ट देखाउन पर्याप्त डाटा छैन।
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
      {/* Contract Distribution by Ward */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-[400px]">
        <h3 className="text-lg font-bold text-gray-800 mb-6">वडागत सम्झौता रकम (Rs.)</h3>
        <ResponsiveContainer width="100%" height="85%">
          <BarChart data={wardData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="ward" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `Rs.${(val/100000).toFixed(0)}L`} />
            <Tooltip 
              cursor={{fill: '#f8fafc'}}
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
            />
            <Bar dataKey="amount" fill="#3b82f6" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Project Status Distribution */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-[400px]">
        <h3 className="text-lg font-bold text-gray-800 mb-6">योजनाको अवस्था</h3>
        <ResponsiveContainer width="100%" height="85%">
          <PieChart>
            <Pie
              data={statusData}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={8}
              dataKey="value"
            >
              {statusData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend verticalAlign="bottom" height={36}/>
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};